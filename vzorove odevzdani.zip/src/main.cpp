#include <iostream>

int wmain(int argc, wchar_t** argv) {



	std::wcout << L"vystup programu" << std::endl;

}